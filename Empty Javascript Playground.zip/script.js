 console.log("Hello World")
 var language = [ "phython", "java script", "C++" ];
 console.log(language)
 for( var i=0; i < language.length; i++ ) {
  console.log(language[i])
 }
 function sumNumbers() {
  let sum = 0;
  for (let i = 1; i <= 100; i++) {
    sum += i;
  }
  return sum;
 }
 const result = sumNumbers();
 console.log(result);